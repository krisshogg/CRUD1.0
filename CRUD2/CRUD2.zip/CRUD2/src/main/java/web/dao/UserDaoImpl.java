package web.dao;

import org.springframework.stereotype.Repository;
import web.model.User;

import java.util.ArrayList;
import java.util.List;

@Repository
public class UserDaoImpl implements UserDao {

    private static int USER_ID;
    private static final List<User> users = new ArrayList<>();

    {
        users.add(new User(++USER_ID, "user1", "?1", "email1"));
        users.add(new User(++USER_ID, "user2", "?2", "email2"));
        users.add(new User(++USER_ID, "user3", "?3", "email3"));
    }

    @Override
    public List<User> index(){
        return users;
    }

    @Override
    public User show(int id){
        return users.stream().filter(user -> user.getId() == id).findAny().orElse(null);
    }

    @Override
    public void save(User user) {
        user.setId(++USER_ID);
        users.add(user);
    }

    @Override
    public void update(int id, User updateUser) {
        User userToBeUpdated = show(id);

        userToBeUpdated.setName((updateUser.getName()));
        userToBeUpdated.setQuestion(updateUser.getQuestion());
        userToBeUpdated.setEmail(updateUser.getEmail());
    }

    @Override
    public void delete(int id) {
        users.removeIf(p -> p.getId() == id);
    }
}
